<?php
session_start();
require 'db.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle flight cancellation first
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_booking'])) {
    try {
        $booking_id = $_POST['booking_id'];
        $user_email = $_SESSION['user_email'];
        
        // Delete only future bookings
        $stmt = $pdo->prepare("DELETE FROM bookings 
                             WHERE id = ? 
                             AND passenger_email = ? 
                             AND travel_date > CURDATE()");
        $stmt->execute([$booking_id, $user_email]);
        
        header("Location: profile.php");
        exit();
    } catch (PDOException $e) {
        die("Cancellation failed: " . $e->getMessage());
    }
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

try {
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT user_id, name, email, created_at FROM users WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    $_SESSION['user_email'] = $user['email'];

    $stmt = $pdo->prepare("SELECT * FROM bookings WHERE passenger_email = ? ORDER BY booking_date DESC");
    $stmt->execute([$user['email']]);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Database error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - AeroHorizon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2563eb;
            --secondary-color: #1e40af;
            --background: #f8fafc;
            --text-dark: #1e293b;
            --danger-red: #ef4444;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }

        body {
            background: var(--background);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .profile-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 20px;
            position: relative;
        }

        .profile-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 3rem 2rem;
            border-radius: 15px;
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
            margin-bottom: 2rem;
        }

        .user-greeting {
            font-size: 2.5rem;
            margin-bottom: 0.5rem;
        }

        .user-details {
            display: flex;
            gap: 1.5rem;
            font-size: 1.1rem;
        }

        .booking-section {
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
            padding: 2rem;
        }

        .section-title {
            font-size: 1.8rem;
            color: var(--secondary-color);
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 3px solid var(--primary-color);
            display: inline-block;
        }

        .booking-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }

        .booking-table th {
            background: var(--primary-color);
            color: white;
            padding: 1rem;
            text-align: left;
        }

        .booking-table td {
            padding: 1rem;
            border-bottom: 1px solid #e2e8f0;
        }

        .booking-table tr:hover {
            background: #f1f5f9;
        }

        .status-badge {
            display: inline-block;
            padding: 0.4rem 0.8rem;
            border-radius: 20px;
            font-weight: 500;
            text-transform: capitalize;
        }

        .status-confirmed {
            background: #dcfce7;
            color: #166534;
        }

        .status-pending {
            background: #fef9c3;
            color: #854d0e;
        }

        .price {
            font-weight: 600;
            color: var(--secondary-color);
        }

        .route {
            font-weight: 500;
            color: var(--text-dark);
        }

        .no-bookings {
            text-align: center;
            padding: 3rem;
            color: #64748b;
        }

        .back-button {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid white;
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            z-index: 999;
        }

        .back-button:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: translateY(-2px);
        }

        .cancel-btn {
            background: var(--danger-red);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 20px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .cancel-btn:hover {
            background: #dc2626;
            transform: translateY(-1px);
        }

        .completed-badge {
            background: #e2e8f0;
            color: #64748b;
            padding: 8px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
        }

        .actions-cell {
            width: 140px;
        }

        @media (max-width: 768px) {
            .profile-header {
                padding: 2rem 1rem;
            }
            
            .booking-table {
                display: block;
                overflow-x: auto;
            }
            
            .back-button {
                top: 10px;
                left: 10px;
                padding: 8px 15px;
                font-size: 0.9rem;
            }
            
            .user-greeting {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'navbar.php'; ?>

    <div class="profile-container">
        <div class="profile-header">
            <h1 class="user-greeting">Welcome, <?php echo htmlspecialchars($user['name']); ?>! 👋</h1>
            <div class="user-details">
                <div><i class="fas fa-envelope"></i> <?php echo htmlspecialchars($user['email']); ?></div>
                <div><i class="fas fa-calendar-check"></i> Member since <?php echo date('M Y', strtotime($user['created_at'])); ?></div>
            </div>
        </div>

        <div class="booking-section">
            <h2 class="section-title"><i class="fas fa-plane-departure"></i> Your Flight Bookings</h2>
            
            <?php if (!empty($bookings)): ?>
                <table class="booking-table">
                    <thead>
                        <tr>
                            <th class="actions-cell">Actions</th>
                            <th>Booking Date</th>
                            <th>Flight</th>
                            <th>Route</th>
                            <th>Travel Date</th>
                            <th>Class</th>
                            <th>Passengers</th>
                            <th>Price</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bookings as $booking): 
                            $is_upcoming = strtotime($booking['travel_date']) > time();
                        ?>
                        <tr>
                            <td class="actions-cell">
                                <?php if ($is_upcoming): ?>
                                <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this booking?');">
                                    <input type="hidden" name="booking_id" value="<?= $booking['id'] ?>">
                                    <button type="submit" name="cancel_booking" class="cancel-btn">
                                        <i class="fas fa-times-circle"></i> Cancel
                                    </button>
                                </form>
                                <?php else: ?>
                                    <div class="completed-badge">
                                        <i class="fas fa-check-circle"></i> Completed
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <i class="fas fa-calendar-alt"></i>
                                <?php echo date('d M Y', strtotime($booking['booking_date'])); ?>
                            </td>
                            <td>✈️ <?php echo htmlspecialchars($booking['flight_id']); ?></td>
                            <td class="route">
                                <?php echo htmlspecialchars($booking['departure_city']); ?> 
                                <i class="fas fa-arrow-right"></i> 
                                <?php echo htmlspecialchars($booking['arrival_city']); ?>
                            </td>
                            <td><?php echo date('d M Y', strtotime($booking['travel_date'])); ?></td>
                            <td><?php echo htmlspecialchars(ucfirst($booking['class'])); ?></td>
                            <td>👥 <?php echo htmlspecialchars($booking['num_passengers']); ?></td>
                            <td class="price">₹<?php echo number_format($booking['price'], 2); ?></td>
                            <td>
                                <span class="status-badge status-<?= strtolower($booking['payment_status']) ?>">
                                    <?php echo htmlspecialchars($booking['payment_status']); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-bookings">
                    <i class="fas fa-plane-slash fa-3x"></i>
                    <p style="margin-top: 1rem;">No bookings found! Ready for your next adventure?</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>