<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');

// Security headers
header("Strict-Transport-Security: max-age=31536000");
header("Content-Security-Policy: default-src 'self'");
header("X-Content-Type-Options: nosniff");
?>