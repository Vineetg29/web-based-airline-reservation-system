
<?php include 'header.php'; ?>
<link rel="stylesheet" href="css/style.css">
<?php
include 'navbar.php';

 
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "airline_reservation";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle search request
$from_city = isset($_GET['from_city']) ? $_GET['from_city'] : '';
$to_city = isset($_GET['to_city']) ? $_GET['to_city'] : '';

$sql = "SELECT * FROM flights";
if ($from_city && $to_city) {
    $sql .= " WHERE departure_city='$from_city' AND arrival_city='$to_city'";
}

$result = $conn->query($sql);
?>

<div class="container mt-5">
    <div class="card shadow-lg p-4 bg-light">
        <h2 class="text-center mb-4"><i class="fas fa-plane-departure"></i> Find Your Flight</h2>

        <!-- Search Form -->
        <form method="GET">
            <div class="row g-3">
                <div class="col-md-5">
                    <label class="form-label">From <i class="fas fa-map-marker-alt"></i></label>
                    <select class="form-select" name="from_city" required>
                        <option value="">Select City</option>
                        <?php 
                        $cities = ["Delhi", "Mumbai", "London", "New York", "Sydney", "Paris", "Tokyo", "Dubai", 
                                   "Bangkok", "Singapore", "Los Angeles", "Toronto", "Berlin", "Madrid", "Chicago",
                                   "San Francisco", "Rome", "Istanbul", "Hong Kong", "Las Vegas", "Mexico City",
                                   "Barcelona", "Vienna", "Moscow", "Jakarta", "Seoul", "Kuala Lumpur", "Beijing",
                                   "Shanghai", "Amsterdam", "Cairo", "Lisbon", "Stockholm", "Brussels", "Athens",
                                   "Warsaw", "Prague", "Zurich", "Helsinki", "Oslo", "Dublin", "Copenhagen",
                                   "Rio de Janeiro", "Buenos Aires", "Santiago", "Bogotá", "Lima", "Cape Town",
                                   "Johannesburg", "Melbourne", "Auckland"];
                        foreach ($cities as $city) {
                            echo "<option value='$city' " . ($from_city == $city ? "selected" : "") . ">$city</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="col-md-5">
                    <label class="form-label">To <i class="fas fa-map-marker-alt"></i></label>
                    <select class="form-select" name="to_city" required>
                        <option value="">Select City</option>
                        <?php 
                        foreach ($cities as $city) {
                            echo "<option value='$city' " . ($to_city == $city ? "selected" : "") . ">$city</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="col-md-2 mt-4">
                    <button type="submit" class="btn btn-primary w-100 py-2">
                        <i class="fas fa-search"></i> Search
                    </button>
                </div>
            </div>
        </form>
    </div>
    <!-- Onboard Services Section -->
<section class="services-section my-5">
    <div class="container">
        <h2 class="text-center mb-5"><i class="fas fa-concierge-bell"></i> Premium Onboard Services</h2>

        <div class="row g-4">
            <!-- Economy Class Card -->
            <div class="col-md-4">
                <div class="service-card economy hover-shadow">
                    <div class="card-header bg-light">
                        <i class="fas fa-chair service-icon economy-icon"></i>
                        <h3 class="mt-3">Economy Class</h3>
                    </div>
                    <div class="card-body">
                        <ul class="service-list">
                            <li><i class="fas fa-check-circle text-success"></i> Complimentary Snacks</li>
                            <li><i class="fas fa-check-circle text-success"></i> Soft Drinks & Water</li>
                            <li><i class="fas fa-check-circle text-success"></i> Standard Meal Options</li>
                        </ul>
                        <div class="price-badge">
                            <span class="badge bg-success">₹5,000 - ₹10,000</span>
                        </div>
                        <button class="btn btn-outline-success w-100 mt-3" data-bs-toggle="modal" data-bs-target="#economyModal">
                            <i class="fas fa-info-circle"></i> More Info
                        </button>
                    </div>
                </div>
            </div>

            <!-- Business Class Card -->
            <div class="col-md-4">
                <div class="service-card business hover-shadow">
                    <div class="card-header bg-light">
                        <i class="fas fa-briefcase service-icon business-icon"></i>
                        <h3 class="mt-3">Business Class</h3>
                    </div>
                    <div class="card-body">
                        <ul class="service-list">
                            <li><i class="fas fa-check-circle text-warning"></i> Gourmet Meals</li>
                            <li><i class="fas fa-check-circle text-warning"></i> Alcoholic Beverages</li>
                            <li><i class="fas fa-check-circle text-warning"></i> Lounge Access</li>
                        </ul>
                        <div class="price-badge">
                            <span class="badge bg-warning">₹15,000 - ₹30,000</span>
                        </div>
                        <button class="btn btn-outline-warning w-100 mt-3" data-bs-toggle="modal" data-bs-target="#businessModal">
                            <i class="fas fa-info-circle"></i> More Info
                        </button>
                    </div>
                </div>
            </div>

            <!-- First Class Card -->
            <div class="col-md-4">
                <div class="service-card first hover-shadow">
                    <div class="card-header bg-light">
                        <i class="fas fa-crown service-icon first-icon"></i>
                        <h3 class="mt-3">First Class</h3>
                    </div>
                    <div class="card-body">
                        <ul class="service-list">
                            <li><i class="fas fa-check-circle text-danger"></i> Premium Multi-Course Meals</li>
                            <li><i class="fas fa-check-circle text-danger"></i> Champagne & Exclusive Wines</li>
                            <li><i class="fas fa-check-circle text-danger"></i> Private Suites</li>
                        </ul>
                        <div class="price-badge">
                            <span class="badge bg-danger">₹50,000 - ₹1,00,000</span>
                        </div>
                        <button class="btn btn-outline-danger w-100 mt-3" data-bs-toggle="modal" data-bs-target="#firstModal">
                            <i class="fas fa-info-circle"></i> More Info
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Modals for Additional Services -->
<!-- Economy Modal -->
<div class="modal fade" id="economyModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title"><i class="fas fa-chair"></i> Economy Class Services</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="service-details">
                    <h6>Included Services:</h6>
                    <ul>
                        <li><i class="fas fa-utensils"></i> 2 Meal Services</li>
                        <li><i class="fas fa-tv"></i> Personal Entertainment Screen</li>
                        <li><i class="fas fa-suitcase-rolling"></i> 20kg Check-in Baggage</li>
                    </ul>
                    <h6>Additional Options:</h6>
                    <ul>
                        <li><i class="fas fa-plus-circle"></i> Extra Legroom Seats</li>
                        <li><i class="fas fa-wifi"></i> WiFi Access (Paid)</li>
                        <li><i class="fas fa-priority"></i> Priority Boarding</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Business Class Modal -->
<div class="modal fade" id="businessModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-warning text-white">
                <h5 class="modal-title"><i class="fas fa-briefcase"></i> Business Class Services</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="service-details">
                    <h6>Included Services:</h6>
                    <ul>
                        <li><i class="fas fa-utensils"></i> 4 Course Gourmet Meals</li>
                        <li><i class="fas fa-wine-glass-alt"></i> Premium Alcoholic Beverages</li>
                        <li><i class="fas fa-luggage-cart"></i> 35kg Check-in Baggage</li>
                        <li><i class="fas fa-couch"></i> Lounge Access</li>
                    </ul>
                    <h6>Additional Options:</h6>
                    <ul>
                        <li><i class="fas fa-bed"></i> Flat-bed Seats</li>
                        <li><i class="fas fa-spa"></i> Lounge Spa Access</li>
                        <li><i class="fas fa-headset"></i> Premium Entertainment System</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- First Class Modal -->
<div class="modal fade" id="firstModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title"><i class="fas fa-crown"></i> First Class Services</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="service-details">
                    <h6>Included Services:</h6>
                    <ul>
                        <li><i class="fas fa-cheese"></i> 7 Course Chef's Special Menu</li>
                        <li><i class="fas fa-wine-bottle"></i> Dom Perignon Champagne</li>
                        <li><i class="fas fa-suitcase"></i> 50kg Check-in Baggage</li>
                        <li><i class="fas fa-door-closed"></i> Private Suite Cabin</li>
                    </ul>
                    <h6>Additional Options:</h6>
                    <ul>
                        <li><i class="fas fa-car-side"></i> Personal Chauffeur Service</li>
                        <li><i class="fas fa-infinity"></i> Unlimited Spa Treatments</li>
                        <li><i class="fas fa-user-secret"></i> Personal Travel Concierge</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add similar modals for Business and First Class -->

<style>
.service-card {
    border-radius: 15px;
    transition: transform 0.3s ease;
    border-top: 4px solid;
}

.hover-shadow:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

.economy { border-color: #28a745; }
.business { border-color: #ffc107; }
.first { border-color: #dc3545; }

.service-icon {
    font-size: 2.5rem;
    margin: 15px 0;
}

.economy-icon { color: #28a745; }
.business-icon { color: #ffc107; }
.first-icon { color: #dc3545; }

.service-list {
    list-style: none;
    padding-left: 0;
}

.service-list li {
    padding: 8px 0;
    border-bottom: 1px solid #eee;
}

.price-badge {
    text-align: center;
    margin: 20px 0;
}

.modal-content {
    border-radius: 15px;
}
</style>
     <h2 class="text-center mt-5"><i class="fas fa-plane"></i> Available Flights</h2>

    <table class="table table-hover table-bordered mt-3">
        <thead class="table-dark">
            <tr>
                <th>Flight Number</th>
                <th>Airline</th>
                <th>From</th>
                <th>To</th>
                <th>Departure</th>
                <th>Time</th>
                <th>Arrival</th>
                <th>Price</th>
                <th>Seats</th>
                <th>Class</th>
                <th>Book</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) { 
                    // Check if this row matches the search
                    $highlight = ($row['departure_city'] == $from_city && $row['arrival_city'] == $to_city) ? 'table-warning' : '';
            ?>
                <tr class="<?php echo $highlight; ?>">
                    <td><?php echo $row['flight_number']; ?></td>
                    <td><?php echo $row['airline']; ?></td>
                    <td><?php echo $row['departure_city']; ?></td>
                    <td><?php echo $row['arrival_city']; ?></td>
                    <td><?php echo $row['departure_date']; ?></td>
                    <td><?php echo $row['departure_time']; ?></td>
                    <td><?php echo $row['arrival_time']; ?></td>
                    <td>₹<?php echo number_format($row['price'], 2); ?></td>
                    <td><?php echo $row['seats_available']; ?></td>
                    <td><?php echo $row['class']; ?></td>
                    <td>
                        <a href="book1.php?id=<?php echo $row['id']; ?>" class="btn btn-success">Book Now</a>
                    </td>
                </tr>
            <?php 
                }
            } else { 
            ?>
                <tr>
                    <td colspan="11" class="text-center text-danger">No Flights Available</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php
$conn->close();
include 'footer.php';
?>
