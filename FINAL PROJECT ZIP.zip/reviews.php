<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: admin_login.php");
    exit();
}

$db = new mysqli('localhost', 'root', '', 'airline_reservation');
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Handle CRUD Operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_review'])) {
        $stmt = $db->prepare("INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $_POST['name'], $_POST['email'], $_POST['subject'], $_POST['message']);
        $stmt->execute();
        header("Location: reviews.php");
        exit();
        
    } elseif (isset($_POST['update_review'])) {
        $stmt = $db->prepare("UPDATE contacts SET name=?, email=?, subject=?, message=? WHERE id=?");
        $stmt->bind_param("ssssi", $_POST['name'], $_POST['email'], $_POST['subject'], $_POST['message'], $_POST['review_id']);
        $stmt->execute();
        header("Location: reviews.php");
        exit();
    }
} elseif (isset($_GET['delete'])) {
    $stmt = $db->prepare("DELETE FROM contacts WHERE id=?");
    $stmt->bind_param("i", $_GET['delete']);
    $stmt->execute();
    header("Location: reviews.php");
    exit();
}

// Fetch Reviews
$reviews = $db->query("SELECT * FROM contacts ORDER BY created_at ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Reviews - SkyAdmin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --light: #ecf0f1;
            --dark: #34495e;
        }

        body { background: #f8f9fa; }

        .sidebar {
            background: var(--primary);
            min-height: 100vh;
            width: 250px;
            position: fixed;
        }

        .sidebar-header {
            padding: 1rem;
            background: var(--dark);
            color: white;
            text-align: center;
        }

        .sidebar-nav a {
            color: var(--light);
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            display: block;
            transition: 0.3s;
        }

        .sidebar-nav a:hover, .sidebar-nav a.active {
            background: var(--secondary);
        }

        .main-content {
            margin-left: 250px;
            width: calc(100% - 250px);
        }

        .top-bar {
            background: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            margin: 2rem;
            padding: 1.5rem;
        }

        .table thead th {
            background: var(--primary);
            color: white;
            border-bottom: none;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .btn-outline-primary {
            border-color: var(--secondary);
            color: var(--secondary);
        }

        .btn-outline-primary:hover {
            background: var(--secondary);
            color: white;
        }
    </style>
</head>
<body>
    <div class="container-fluid p-0">
        <div class="row g-0">
            <!-- Sidebar -->
            <div class="sidebar">
                <div class="sidebar-header">
                    <h3 class="mb-0"><i class="fas fa-plane me-2"></i>SkyAdmin</h3>
                </div>
                <nav class="sidebar-nav py-3">
                    <a href="admin_dashboard.php"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a href="manage_bookings.php"><i class="fas fa-calendar-check me-2"></i>Bookings</a>
                    <a href="manage_flights.php"><i class="fas fa-plane-departure me-2"></i>Flights</a>
                    <a href="manage_users.php"><i class="fas fa-users me-2"></i>Users</a>
                    <a href="reviews.php" class="active"><i class="fas fa-comments me-2"></i>Reviews</a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="main-content">
                <!-- Top Bar -->
                <div class="top-bar">
                    <h4 class="mb-0">Manage Reviews</h4>
                    <div class="d-flex align-items-center">
                        <div class="user-profile">
                            <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['user_name']) ?>&background=3498db&color=fff" alt="Profile">
                            <span class="me-3"><?= $_SESSION['user_name'] ?></span>
                        </div>
                        <a href="logout.php" class="btn btn-danger btn-sm">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>

                <!-- Content -->
                <div class="table-container">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5>Customer Reviews</h5>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addReviewModal">
                            <i class="fas fa-plus me-2"></i>Add Review
                        </button>
                    </div>

                    <!-- Reviews Table -->
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($review = $reviews->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $review['id'] ?></td>
                                    <td><?= htmlspecialchars($review['name']) ?></td>
                                    <td><?= htmlspecialchars($review['email']) ?></td>
                                    <td><?= htmlspecialchars($review['subject']) ?></td>
                                    <td><?= date('M d, Y', strtotime($review['created_at'])) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary edit-review" 
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editReviewModal"
                                                data-id="<?= $review['id'] ?>"
                                                data-name="<?= htmlspecialchars($review['name']) ?>"
                                                data-email="<?= htmlspecialchars($review['email']) ?>"
                                                data-subject="<?= htmlspecialchars($review['subject']) ?>"
                                                data-message="<?= htmlspecialchars($review['message']) ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="reviews.php?delete=<?= $review['id'] ?>" 
                                           class="btn btn-sm btn-outline-danger" 
                                           onclick="return confirm('Are you sure you want to delete this review?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Review Modal -->
    <div class="modal fade" id="addReviewModal" tabindex="-1" aria-labelledby="addReviewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="addReviewModalLabel"><i class="fas fa-plus me-2"></i>Add New Review</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" class="form-control" name="subject" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Message</label>
                            <textarea class="form-control" name="message" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_review" class="btn btn-primary">Add Review</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Review Modal -->
    <div class="modal fade" id="editReviewModal" tabindex="-1" aria-labelledby="editReviewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="review_id" id="editReviewId">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="editReviewModalLabel"><i class="fas fa-edit me-2"></i>Edit Review</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" class="form-control" name="name" id="editName" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" class="form-control" name="email" id="editEmail" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Subject</label>
                            <input type="text" class="form-control" name="subject" id="editSubject" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Message</label>
                            <textarea class="form-control" name="message" id="editMessage" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_review" class="btn btn-primary">Update Review</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Edit Review Modal Handler
        document.querySelectorAll('.edit-review').forEach(button => {
            button.addEventListener('click', () => {
                document.getElementById('editReviewId').value = button.dataset.id;
                document.getElementById('editName').value = button.dataset.name;
                document.getElementById('editEmail').value = button.dataset.email;
                document.getElementById('editSubject').value = button.dataset.subject;
                document.getElementById('editMessage').value = button.dataset.message;
            });
        });
    </script>
</body>
</html>
<?php $db->close(); ?>