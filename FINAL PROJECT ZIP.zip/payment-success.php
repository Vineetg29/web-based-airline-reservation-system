<?php
session_start();
if (!isset($_SESSION['booking_details'])) {
    header("Location: index.php"); // Redirect to homepage if no booking details are found
    exit();
}

$booking = $_SESSION['booking_details']; // Retrieve booking details from session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful - Airline Reservation</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background: url('images/success-bg.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 80px;
        }
        .card {
            background: rgba(0, 0, 0, 0.7);
            border-radius: 15px;
            padding: 20px;
            text-align: center;
        }
        .checkmark {
            font-size: 60px;
            color: #28a745;
            animation: bounce 1s infinite;
        }
        @keyframes bounce {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.2); }
        }
        .btn-custom {
            width: 100%;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="container d-flex justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-lg p-4">
            <i class="fa-solid fa-circle-check checkmark"></i>
            <h2 class="mt-3">Payment Successful!</h2>
            <p>Thank you for booking with us. Your reservation details are below.</p>

            <table class="table table-dark table-striped mt-3">
                <tr>
                    <th>Booking ID</th>
                    <td><?php echo $booking['id']; ?></td>
                </tr>
                <tr>
                    <th>Passenger Name</th>
                    <td><?php echo $booking['name']; ?></td>
                </tr>
                <tr>
                    <th>Flight</th>
                    <td><?php echo $booking['flight']; ?></td>
                </tr>
                <tr>
                    <th>Departure</th>
                    <td><?php echo $booking['departure']; ?></td>
                </tr>
                <tr>
                    <th>Arrival</th>
                    <td><?php echo $booking['arrival']; ?></td>
                </tr>
                <tr>
                    <th>Date</th>
                    <td><?php echo $booking['date']; ?></td>
                </tr>
                <tr>
                    <th>Seat</th>
                    <td><?php echo $booking['seat']; ?></td>
                </tr>
            </table>

            <a href="index.php" class="btn btn-success btn-custom">Go to Homepage</a>
            <a href="my-bookings.php" class="btn btn-primary btn-custom">View My Bookings</a>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
