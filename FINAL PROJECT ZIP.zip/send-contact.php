<?php
require_once 'db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CSRF Protection
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    $_SESSION['error'] = "Security token mismatch!";
    header("Location: contact.php");
    exit();
}

unset($_SESSION['csrf_token']); // Prevent CSRF reuse

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars(trim($_POST['name']), ENT_QUOTES, 'UTF-8');
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $subject = htmlspecialchars(trim($_POST['subject']), ENT_QUOTES, 'UTF-8');
    $message = htmlspecialchars(trim($_POST['message']), ENT_QUOTES, 'UTF-8');

    // Validation
    $errors = [];

    if (empty($name)) $errors[] = "Name is required.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format.";
    if (empty($subject)) $errors[] = "Subject is required.";
    if (strlen($message) < 10) $errors[] = "Message should be at least 10 characters.";

    if (!empty($errors)) {
        $_SESSION['error'] = implode("<br>", $errors);
        header("Location: contact.php");
        exit();
    }

    try {
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO contacts (name, email, subject, message) 
                               VALUES (:name, :email, :subject, :message)");
        
        $stmt->execute([
            ':name' => $name,
            ':email' => $email,
            ':subject' => $subject,
            ':message' => $message
        ]);

        $_SESSION['success'] = "Your message has been sent successfully!";
        
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $_SESSION['error'] = "Failed to send message. Please try again.";
    }

    header("Location: contact.php");
    exit();
}
