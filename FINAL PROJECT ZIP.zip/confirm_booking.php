<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $flight_id = $_POST['flight_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $stmt = $pdo->prepare("INSERT INTO bookings (flight_id, name, email, phone) VALUES (?, ?, ?, ?)");
    $stmt->execute([$flight_id, $name, $email, $phone]);

    echo "<div class='alert alert-success'>Booking Successful!</div>";
} else {
    echo "<div class='alert alert-danger'>Invalid Request!</div>";
}
?>
