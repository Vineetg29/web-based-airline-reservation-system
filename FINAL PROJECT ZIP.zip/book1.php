<?php
session_start();   
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Please login to book a flight.";
    header("Location: login.php");
    exit();
} 
include 'header.php';
include 'navbar.php';
include 'db.php'; // PDO connection file

// Fetch flight details
$flight = [];
if(isset($_GET['id'])) {
    try {
        $flight_id = $_GET['id'];
        $stmt = $pdo->prepare("SELECT * FROM flights WHERE id = ?");
        $stmt->execute([$flight_id]);
        $flight = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if(!$flight) {
            die("<div class='alert alert-danger'>Flight not found!</div>");
        }
    } catch(PDOException $e) {
        die("<div class='alert alert-danger'>Error fetching flight: " . $e->getMessage() . "</div>");
    }
}

// Process form submission
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $pdo->beginTransaction();

        // Validate and collect data
        $main_passenger = [
            'name' => filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING),
            'email' => filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL),
            'phone' => filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING)
        ];

        $passengers = (int)$_POST['passengers'];
        $passenger_details = json_encode($_POST['passengers_data']);
        $selected_seats = $_POST['selected_seats'];
        
        if($passengers < 1 || $passengers > ($flight['seats_available'] ?? 0)) {
            throw new Exception("Invalid number of passengers");
        }
        // Validate required fields
        if(!$main_passenger['name'] || !$main_passenger['email'] || !$main_passenger['phone']) {
            throw new Exception("All passenger fields are required");
        }

        // Insert booking
        $stmt = $pdo->prepare("INSERT INTO bookings (
            flight_id, departure_city, arrival_city, travel_date, 
            class, price, passenger_name, passenger_email, 
            passenger_phone, num_passengers, passenger_details, selected_seats
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        $stmt->execute([
            $flight['flight_number'],
            $flight['departure_city'],
            $flight['arrival_city'],
            $flight['departure_date'],
            $flight['class'],
            $flight['price'],
            $main_passenger['name'],
            $main_passenger['email'],
            $main_passenger['phone'],
            $passengers,
            $passenger_details,
            $selected_seats
        ]);

        // Get booking ID and update session
        $booking_id = $pdo->lastInsertId();
        $_SESSION['booking_id'] = $booking_id;

        // Update available seats
        $update_stmt = $pdo->prepare("UPDATE flights SET seats_available = seats_available - ? WHERE id = ?");
        $update_stmt->execute([$passengers, $flight['id']]);

        $pdo->commit();

        header("Location: payment.php");
        exit();

    } catch(PDOException $e) {
        $pdo->rollBack();
        $error = "Database error: " . $e->getMessage();
    } catch(Exception $e) {
        $pdo->rollBack();
        $error = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Flight - AeroHorizon</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <style>
        :root {
            --primary: #2563eb;
            --secondary: #1d4ed8;
            --accent: #f59e0b;
            --light: #f8fafc;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%);
            min-height: 100vh;
        }

        .booking-card {
            border-radius: 1rem;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            border: none;
            overflow: hidden;
        }

        .progress-steps {
            position: relative;
            display: flex;
            justify-content: space-between;
            margin: 2rem 0 3rem;
        }

        .progress-step {
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            z-index: 1;
            width: 25%;
        }

        .progress-step .step-bubble {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #cbd5e1;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-bottom: 0.5rem;
            transition: all 0.3s ease;
        }

        .progress-step.active .step-bubble {
            background: var(--primary);
            transform: scale(1.1);
        }

        .flight-info-card {
            background: white;
            border-radius: 0.75rem;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        }

        .seat-map {
            display: grid;
            grid-template-columns: repeat(8, 1fr);
            gap: 0.75rem;
            padding: 1.5rem;
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        }

        .seat {
            position: relative;
            padding: 0.75rem;
            text-align: center;
            border-radius: 0.5rem;
            cursor: pointer;
            transition: all 0.2s ease;
            background: white;
            border: 2px solid #e2e8f0;
        }

        .seat.selected {
            background: var(--primary);
            color: white;
            border-color: var(--primary);
        }

        .seat.occupied {
            background: #fee2e2;
            color: #dc2626;
            cursor: not-allowed;
        }

        .passenger-group {
            background: white;
            padding: 1.25rem;
            border-radius: 0.75rem;
            margin-bottom: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .form-control {
            border: 2px solid #e2e8f0;
            border-radius: 0.5rem;
            padding: 0.75rem 1rem;
            transition: border-color 0.2s ease;
        }

        .btn-primary {
            background: var(--primary);
            padding: 1rem 2rem;
            font-size: 1.1rem;
            border-radius: 0.75rem;
            transition: all 0.2s ease;
        }

        .btn-primary:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-xl-10">
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger mb-4"><?= $error ?></div>
                <?php endif; ?>

                <div class="booking-card">
                    <div class="card-header bg-primary text-white py-4">
                        <h3 class="mb-0 text-center"><i class="fas fa-ticket-alt mr-2"></i>Book Your Flight</h3>
                    </div>

                    <div class="card-body p-4">
                        <!-- Progress Steps -->
                        <div class="progress-steps">
                            <div class="progress-step active">
                                <div class="step-bubble"><i class="fas fa-plane"></i></div>
                                <span class="text-sm">Flight Details</span>
                            </div>
                            <div class="progress-step">
                                <div class="step-bubble"><i class="fas fa-users"></i></div>
                                <span class="text-sm">Passengers</span>
                            </div>
                            <div class="progress-step">
                                <div class="step-bubble"><i class="fas fa-chair"></i></div>
                                <span class="text-sm">Seats</span>
                            </div>
                            <div class="progress-step">
                                <div class="step-bubble"><i class="fas fa-check"></i></div>
                                <span class="text-sm">Confirm</span>
                            </div>
                        </div>

                        <!-- Flight Information -->
                        <div class="flight-info-card">
                            <h4 class="text-primary mb-4"><i class="fas fa-plane-departure"></i> Flight Details</h4>
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Flight Number</label>
                                    <input type="text" class="form-control" value="<?= htmlspecialchars($flight['flight_number'] ?? '') ?>" readonly>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Class</label>
                                    <input type="text" class="form-control" value="<?= htmlspecialchars(ucfirst($flight['class'] ?? '')) ?>" readonly>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label">Departure</label>
                                    <input type="text" class="form-control" value="<?= date('d M Y', strtotime($flight['departure_date'] ?? '')) ?>" readonly>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <div class="d-flex align-items-center h-100">
                                        <div class="flight-route">
                                            <div class="h5 mb-0"><?= htmlspecialchars($flight['departure_city'] ?? '') ?></div>
                                            <div class="text-muted small">Departure</div>
                                        </div>
                                        <i class="fas fa-arrow-right mx-3 text-primary"></i>
                                        <div class="flight-route">
                                            <div class="h5 mb-0"><?= htmlspecialchars($flight['arrival_city'] ?? '') ?></div>
                                            <div class="text-muted small">Arrival</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Total Price</label>
                                    <div class="input-group">
                                        <span class="input-group-text">₹</span>
                                        <input type="text" class="form-control font-weight-bold" 
                                            value="<?= isset($flight['price']) ? number_format($flight['price'] * ($_POST['passengers'] ?? 1), 2) : '0.00' ?>" 
                                            readonly>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Booking Form -->
                        <form method="POST">
                            <!-- Passenger Details Section -->
                            <div class="flight-info-card">
                                <h4 class="text-primary mb-4"><i class="fas fa-users"></i> Passenger Information</h4>
                                
                                <!-- Main Passenger -->
                                <div class="row g-3 mb-4">
                                    <div class="col-md-4">
                                        <label class="form-label">Main Passenger Name</label>
                                        <input type="text" name="name" class="form-control" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Email Address</label>
                                        <input type="email" name="email" class="form-control" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label">Phone Number</label>
                                        <input type="tel" name="phone" class="form-control" required>
                                    </div>
                                </div>

                                <!-- Additional Passengers -->
                                <div class="mb-4">
                                    <label class="form-label">Number of Passengers</label>
                                    <div class="d-flex align-items-center">
                                        <input type="number" id="num-passengers" name="passengers" class="form-control mr-3" 
                                            style="max-width: 100px"
                                            min="1" max="<?= $flight['seats_available'] ?? 0 ?>" value="1" required
                                            onchange="generatePassengerFields()">
                                        <small class="text-muted"><?= $flight['seats_available'] ?? 0 ?> seats available</small>
                                    </div>
                                </div>
                                
                                <div id="passenger-fields" class="mt-3"></div>
                            </div>

                            <!-- Seat Selection -->
                            <div class="flight-info-card" id="seat-section">
                                <h4 class="text-primary mb-4"><i class="fas fa-chair"></i> Seat Selection</h4>
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle mr-2"></i>
                                    Click available seats to select. Selected seats will turn blue.
                                </div>
                                <div class="seat-map" id="seat-map"></div>
                                <input type="hidden" name="selected_seats" id="selected-seats">
                            </div>

                            <!-- Submit Button -->
                            <div class="mt-4 text-center">
                                <button type="submit" class="btn btn-primary btn-lg px-5">
                                    <i class="fas fa-credit-card mr-2"></i>Proceed to Payment
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    function generatePassengerFields() {
        const numPassengers = document.getElementById('num-passengers').value;
        const container = document.getElementById('passenger-fields');
        container.innerHTML = '';
        
        for(let i = 1; i <= numPassengers; i++) {
            container.innerHTML += `
                <div class="passenger-group">
                    <h5 class="mb-3 text-primary">Passenger ${i}</h5>
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="passengers_data[${i}][name]" class="form-control" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Age</label>
                            <input type="number" name="passengers_data[${i}][age]" class="form-control" min="1" max="120" required>
                        </div>
                    </div>
                </div>`;
        }
        
        generateSeatMap(numPassengers);
    }

    function generateSeatMap(maxSeats) {
        const seatMap = document.getElementById('seat-map');
        seatMap.innerHTML = '<div class="text-center py-3"><i class="fas fa-spinner fa-spin"></i> Loading seat map...</div>';

        setTimeout(() => {
            seatMap.innerHTML = '';
            const rows = ['A', 'B', 'C', 'D', 'E', 'F'];
            let selectedSeats = [];
            
            rows.forEach(row => {
                for(let num = 1; num <= 8; num++) {
                    const seat = document.createElement('div');
                    seat.className = 'seat';
                    seat.textContent = `${row}${num}`;
                    
                    seat.addEventListener('click', () => {
                        if(seat.classList.contains('occupied')) return;
                        
                        if(seat.classList.contains('selected')) {
                            seat.classList.remove('selected');
                            selectedSeats = selectedSeats.filter(s => s !== seat.textContent);
                        } else {
                            if(selectedSeats.length < maxSeats) {
                                seat.classList.add('selected');
                                selectedSeats.push(seat.textContent);
                            }
                        }
                        document.getElementById('selected-seats').value = selectedSeats.join(',');
                    });
                    
                    seatMap.appendChild(seat);
                }
            });

            // Mark random seats as occupied
            const allSeats = document.querySelectorAll('.seat');
            allSeats.forEach(seat => {
                if(Math.random() < 0.3) seat.classList.add('occupied');
            });
        }, 500);
    }
    </script>

<?php 
$pdo = null; // Close connection
include 'footer.php'; 
?>
</body>
</html>