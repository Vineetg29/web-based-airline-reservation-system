<?php include 'header.php'; ?>
<?php include 'navbar.php'; ?>

<!-- Hero Carousel Section -->
<div id="heroCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <img src="a5.jpg" class="d-block w-100" alt="Flight 1">
        </div>
        <div class="carousel-item">
            <img src="a7.webp" class="d-block w-100" alt="Flight 2">
        </div>
        <div class="carousel-item">
            <img src="a8.webp" class="d-block w-100" alt="Flight 3">
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
    </button>
</div>

<!-- Flight Booking Form -->
<div class="container booking-box shadow-lg p-4 rounded bg-white mt-4">
    <h4 class="mb-3"><i class="fa fa-plane"></i> Book a Flight</h4>
    <form id="flightForm" action="search-form.php" method="GET" onsubmit="return validateForm()">
        <div class="row g-3">
            <div class="col-md-2">
                <label class="form-label">Trip Type</label>
                <select class="form-select" name="trip">
                    <option value="oneway">One Way</option>
                    <option value="roundtrip">Round Trip</option>
                    <option value="multicity">Multi City</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">From</label>
                <input type="text" class="form-control" name="from" id="from" placeholder="Departure city" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">To</label>
                <input type="text" class="form-control" name="to" id="to" placeholder="Destination city" required>
            </div>
            <div class="col-md-2">
                <label class="form-label">Departure</label>
                <input type="date" class="form-control" name="departure" id="departure" required>
            </div>
            <div class="col-md-2">
                <label class="form-label">Return</label>
                <input type="date" class="form-control" name="return" id="return">
            </div>
        </div>
        <div class="row g-3 mt-2">
            <div class="col-md-3">
                <label class="form-label">Travellers</label>
                <select class="form-select" name="travellers">
                    <option value="1">1 Passenger</option>
                    <option value="2">2 Passengers</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Class</label>
                <select class="form-select" name="class">
                    <option value="economy">Economy</option>
                    <option value="business">Business</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">Promo Code</label>
                <input type="text" class="form-control" name="promo" placeholder="Enter promo code">
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">Search Flights</button>
            </div>
        </div>
    </form>
</div>

<script>
function validateForm() {
    let today = new Date().toISOString().split("T")[0]; // Get current date in YYYY-MM-DD format
    let departure = document.getElementById("departure").value;
    let returnDate = document.getElementById("return").value;
    let fromCity = document.getElementById("from").value.trim().toLowerCase();
    let toCity = document.getElementById("to").value.trim().toLowerCase();

    if (departure < today) {
        alert("Departure date cannot be before today.");
        return false;
    }

    if (returnDate && returnDate < departure) {
        alert("Return date cannot be before departure date.");
        return false;
    }

    if (fromCity === toCity) {
        alert("Departure and destination cities cannot be the same.");
        return false;
    }

    return true;
}
</script>

<!-- Popular Destinations -->
<div class="container my-5">
    <h2 class="text-center mb-4">Popular Destinations</h2>
    <div class="row">
        <?php 
        $destinations = [
            ["image" => "d1.jpg", "title" => "Paris, France"],
            ["image" => "d3.jpg", "title" => "Tokyo, Japan"],
            ["image" => "d2.jpg", "title" => "Dubai, UAE"],
            ["image" => "d4.jpg", "title" => "New York, USA"],
            ["image" => "d5.jpg", "title" => "Rome, Italy"],
            ["image" => "d6.jpg", "title" => "Sydney, Australia"]
        ];
        foreach ($destinations as $destination) {
            echo '
            <div class="col-md-4 mb-4">
                <div class="card border-0 shadow-lg">
                    <img src="' . $destination["image"] . '" class="card-img-top destination-img" alt="' . $destination["title"] . '">
                    <div class="card-body text-center">
                        <h4 class="card-title">' . $destination["title"] . '</h4>
                    </div>
                </div>
            </div>';
        }
        ?>
    </div>
</div>

<!-- Styles for Destination Images -->
<style>
    .destination-img {
        height: 250px;
        object-fit: cover;
        transition: transform 0.3s ease-in-out;
    }
    .destination-img:hover {
        transform: scale(1.05);
    }
</style>

<!-- Why Choose Us -->
<div class="container-fluid bg-light py-5">
    <h2 class="text-center">Why Choose Us?</h2>
    <div class="row text-center mt-4">
        <div class="col-md-3">
            <i class="fa fa-plane fa-3x"></i>
            <h4>Best Deals</h4>
            <p>Exclusive flight discounts.</p>
        </div>
        <div class="col-md-3">
            <i class="fa fa-clock fa-3x"></i>
            <h4>24/7 Support</h4>
            <p>Always here to help.</p>
        </div>
        <div class="col-md-3">
            <i class="fa fa-star fa-3x"></i>
            <h4>Trusted by Millions</h4>
            <p>Reliable service for travelers.</p>
        </div>
        <div class="col-md-3">
            <i class="fa fa-shield-alt fa-3x"></i>
            <h4>Secure Payments</h4>
            <p>Safe transactions always.</p>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>
