<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'header.php';
include 'navbar.php';
include 'db.php';

// Initialize variables
$booking = [];
$error = '';
$payment_success = false;

// Check for existing successful payment
if (isset($_SESSION['payment_success']) && $_SESSION['payment_success']) {
    $payment_success = true;
    unset($_SESSION['payment_success']);
}

try {
    if (!isset($_SESSION['booking_id']) && !$payment_success) {
        header("Location: book1.php");
        exit();
    }

    $booking_id = $_SESSION['booking_id'];
    
    // Fetch booking details
    $stmt = $pdo->prepare("SELECT * FROM bookings WHERE id = ?");
    $stmt->execute([$booking_id]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$booking) {
        throw new Exception("Booking details not found!");
    }

    // Handle payment submission
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && !$payment_success) {
        $pdo->beginTransaction();

        $payment_method = $_POST['payment_method'];
        $payment_details = [];

        if ($payment_method === 'card') {
            $card_number = preg_replace('/\D/', '', $_POST['card_number'] ?? '');
            $expiry = preg_replace('/\D/', '', $_POST['expiry'] ?? '');
            $cvc = preg_replace('/\D/', '', $_POST['cvc'] ?? '');

            if (!preg_match('/^\d{16}$/', $card_number)) {
                throw new Exception("Invalid card number (16 digits required)");
            }

            if (strlen($expiry) !== 4 || !preg_match('/^(0[1-9]|1[0-2])([0-9]{2})$/', $expiry)) {
                throw new Exception("Invalid expiry date (MMYY format required)");
            }

            $month = substr($expiry, 0, 2);
            $year = '20'.substr($expiry, 2, 2);
            $currentYear = (int)date('Y');
            $currentMonth = (int)date('m');
            
            if ((int)$year < $currentYear || ((int)$year == $currentYear && (int)$month < $currentMonth)) {
                throw new Exception("Card has expired");
            }

            if (!preg_match('/^\d{3,4}$/', $cvc)) {
                throw new Exception("Invalid CVC (3-4 digits required)");
            }

            $payment_details = [
                'card_number' => $card_number,
                'expiry' => $month.'/'.substr($expiry, 2, 2),
                'cvc' => $cvc
            ];
            
        } elseif ($payment_method === 'upi') {
            $upi_id = trim($_POST['upi_id'] ?? '');
            
            if (!preg_match('/^[\w.-]+@[\w.-]+$/', $upi_id)) {
                throw new Exception("Invalid UPI ID (format: name@upi)");
            }
            
            $payment_details = ['upi_id' => $upi_id];
        } else {
            throw new Exception("Invalid payment method");
        }

        // Update payment status
        $stmt = $pdo->prepare("UPDATE bookings SET 
            payment_status = 'completed',
            payment_method = ?,
            payment_details = ?,
            payment_date = NOW()
            WHERE id = ?");

        $stmt->execute([
            $payment_method,
            json_encode($payment_details),
            $booking_id
        ]);

        $pdo->commit();

        $_SESSION['payment_success'] = true;
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    }

} catch (PDOException $e) {
    error_log("Database Error: " . $e->getMessage());
    $error = "Payment processing failed. Please try again.";
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
} catch (Exception $e) {
    error_log("Payment Error: " . $e->getMessage());
    $error = $e->getMessage();
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Add before existing styles -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #2563eb;
            --success: #16a34a;
        }

        .payment-card {
            background: #fff;
            border-radius: 1.5rem;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .method-tab {
            flex: 1;
            text-align: center;
            padding: 1.5rem;
            border: 2px solid #dee2e6;
            border-radius: 0.75rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .method-tab.active {
            border-color: #0d6efd;
            background: rgba(13, 110, 253, 0.05);
            transform: translateY(-2px);
        }

        .method-tab i {
            color: #6c757d;
            transition: color 0.3s ease;
        }

        .method-tab.active i {
            color: #0d6efd;
        }

        .payment-form {
            display: none;
            animation: slideUp 0.3s ease;
        }

        .payment-form.active {
            display: block;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(13, 110, 253, 0.25);
        }
        /* Modern Confirmation Design */
        .confirmation-card {
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            border-radius: 1.5rem;
            padding: 4rem 2rem;
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
        }

        .checkmark-circle {
            width: 100px;
            height: 100px;
            background: var(--success);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 2rem;
        }

        .checkmark-circle i {
            color: white;
            font-size: 3.5rem;
        }

        /* Modern Ticket Design */
        .ticket-section {
            background: white;
            border-radius: 1.5rem;
            box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1);
            border: 1px solid #e2e8f0;
            max-width: 640px;
            margin: 2rem auto;
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .ticket-section.visible {
            opacity: 1;
            transform: translateY(0);
        }

        .ticket-header {
            background: linear-gradient(45deg, var(--primary), #3b82f6);
            color: white;
            padding: 2rem;
            border-radius: 1.5rem 1.5rem 0 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .ticket-header::after {
            content: "";
            position: absolute;
            bottom: -20px;
            left: 0;
            right: 0;
            height: 40px;
            background: white;
            clip-path: polygon(0 0, 100% 0, 50% 100%);
        }

        .ticket-qr {
            background: white;
            padding: 1rem;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
            width: 160px;
            margin: 1rem auto;
        }

        .ticket-details {
            padding: 2rem;
            position: relative;
        }

        .detail-card {
            background: #f8fafc;
            border-radius: 1rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .detail-card h5 {
            color: var(--primary);
            margin-bottom: 1rem;
        }

        .airline-branding {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .airline-logo {
            width: 50px;
            height: 50px;
            background: #bfdbfe;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        /* Timeline */
        .timeline {
            display: flex;
            justify-content: space-between;
            position: relative;
            margin: 2rem 0;
        }

        .timeline::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 2px;
            background: #cbd5e1;
            transform: translateY(-50%);
        }

        .timeline-item {
            text-align: center;
            z-index: 1;
            background: white;
            padding: 0 1rem;
        }

        .timeline-dot {
            width: 16px;
            height: 16px;
            background: var(--primary);
            border-radius: 50%;
            margin: 0 auto 0.5rem;
        }

        /* Print Styles */
        @media print {
            body * {
                visibility: hidden !important;
            }

            .ticket-section, .ticket-section * {
                visibility: visible !important;
            }

            .ticket-section {
                box-shadow: none;
                border: 2px solid #000;
                page-break-after: always;
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
            }

            .no-print, .btn {
                display: none !important;
            }
        }
    </style>
</head>
<body>
    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay" style="display: none;">
        <div class="d-flex justify-content-center align-items-center h-100">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Loading...</span>
            </div>
        </div>
    </div>

    <div class="container py-5">
        <?php if($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php elseif($payment_success): ?>
            <!-- Success Section -->
            <div class="confirmation-card">
                <div class="text-center mb-5">
                    <div class="checkmark-circle">
                        <i class="fas fa-check"></i>
                    </div>
                    <h1 class="display-5 fw-bold mb-3">Payment Successful!</h1>
                    <p class="lead text-muted">Your booking has been confirmed. Please find your e-ticket below.</p>
                    
                    <div class="d-flex gap-3 justify-content-center mb-5">
                        <button onclick="toggleTicket()" class="btn btn-primary px-4 py-2">
                            <i class="fas fa-ticket-alt me-2"></i>Show Ticket
                        </button>
                        <a href="index.php" class="btn btn-outline-secondary px-4 py-2">
                            <i class="fas fa-home me-2"></i>Return Home
                        </a>
                    </div>
                </div>

                <!-- Enhanced Ticket Design -->
                <div class="ticket-section" id="ticketContainer">
                    <div class="ticket-header">
                        <div class="airline-branding justify-content-center">
                            <div class="airline-logo">
                                <i class="fas fa-plane text-primary"></i>
                            </div>
                            <h2 class="mb-0">Skyways Airline Tickets</h2>
                        </div>
                    </div>

                    <div class="ticket-details">
                        <!-- Timeline -->
                        <div class="timeline">
                            <div class="timeline-item">
                                <div class="timeline-dot"></div>
                                <div class="text-muted small"><?= substr(strtoupper($booking['departure_city']), 0, 3) ?></div>
                                <div class="fw-bold">Departure</div>
                            </div>
                            <div class="timeline-item">
                                <div class="timeline-dot"></div>
                                <div class="text-muted small">Flight</div>
                                <div class="fw-bold">AA<?= rand(100, 999) ?></div>
                            </div>
                            <div class="timeline-item">
                                <div class="timeline-dot"></div>
                                <div class="text-muted small"><?= substr(strtoupper($booking['arrival_city']), 0, 3) ?></div>
                                <div class="fw-bold">Arrival</div>
                            </div>
                        </div>

                        <!-- QR Code -->
                        <div class="text-center mb-4">
                            <div class="ticket-qr">
                                <img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=<?= urlencode($booking['id']) ?>" 
                                     alt="QR Code" class="img-fluid">
                            </div>
                            <p class="text-muted mb-0">Scan this code at airport check-in</p>
                        </div>

                        <!-- Details Grid -->
                        <div class="row g-4">
                            <div class="col-md-6">
                                <div class="detail-card">
                                    <h5><i class="fas fa-user me-2"></i>Passenger Details</h5>
                                    <div class="row">
                                        <div class="col-6 text-muted">Name:</div>
                                        <div class="col-6 fw-bold"><?= htmlspecialchars($booking['passenger_name']) ?></div>
                                        <div class="col-8 text-muted">Email:</div>
                                        <div class="col-8 fw-bold"><?= htmlspecialchars($booking['passenger_email']) ?></div>
                                        <div class="col-6 text-muted">Passengers:</div>
                                        <div class="col-6 fw-bold"><?= $booking['num_passengers'] ?></div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="detail-card">
                                    <h5><i class="fas fa-plane me-2"></i>Flight Details</h5>
                                    <div class="row">
                                        <div class="col-6 text-muted">Departure:</div>
                                        <div class="col-6 fw-bold"><?= date('d M Y, H:i', strtotime($booking['booking_date'])) ?></div>
                                        <div class="col-6 text-muted">From:</div>
                                        <div class="col-6 fw-bold"><?= htmlspecialchars($booking['departure_city']) ?></div>
                                        <div class="col-6 text-muted">To:</div>
                                        <div class="col-6 fw-bold"><?= htmlspecialchars($booking['arrival_city']) ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Terms -->
                        <div class="text-center text-muted small mt-4">
    <div class="mb-2 fw-bold">Booking ID: #<?= $booking['id'] ?></div>
    <div class="mb-2 fw-bold">Issued at: <?= date('d M Y H:i') ?></div>
    <div class="fw-bold">Please arrive at least 2 hours before departure</div>
</div>

                        <!-- Print Button -->
                        <div class="text-center mt-4 no-print">
                            <button onclick="window.print()" class="btn btn-primary">
                                <i class="fas fa-print me-2"></i>Print Ticket
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- ... [Keep existing payment form same] ... -->
              <!-- Enhanced Payment Form -->
              <div class="payment-card">
                        <div class="payment-header bg-primary text-white p-4">
                            <h2 class="mb-0 text-center"><i class="fas fa-lock me-2"></i>Secure Payment Gateway</h2>
                        </div>

                        <div class="card-body p-4">
                            <div class="row g-4">
                                <!-- Booking Summary -->
                                <div class="col-md-5">
                                    <h4 class="mb-4"><i class="fas fa-receipt me-2"></i>Booking Summary</h4>
                                    <div class="bg-light p-3 rounded-3 border">
                                        <div class="d-flex justify-content-between mb-2">
                                            <span>Booking ID:</span>
                                            <span class="fw-bold">#<?= $booking['id'] ?></span>
                                        </div>
                                        <div class="d-flex justify-content-between mb-3">
                                            <span>Route:</span>
                                            <span class="text-end">
                                                <?= $booking['departure_city'] ?> 
                                                <i class="fas fa-arrow-right mx-1"></i>
                                                <?= $booking['arrival_city'] ?>
                                            </span>
                                        </div>
                                        <div class="alert alert-success mb-0 py-2">
                                            <div class="d-flex justify-content-between fw-bold">
                                                <span>Total:</span>
                                                <span>₹<?= number_format($booking['price'] * $booking['num_passengers'], 2) ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Payment Methods -->
                                <div class="col-md-7">
                                    <div class="d-flex gap-3 mb-4">
                                        <div class="method-tab active" data-method="card">
                                            <i class="fas fa-credit-card fa-2x mb-2"></i>
                                            <div>Credit/Debit Card</div>
                                        </div>
                                        <div class="method-tab" data-method="upi">
                                            <i class="fas fa-mobile-alt fa-2x mb-2"></i>
                                            <div>UPI Payment</div>
                                        </div>
                                    </div>

                                    <form method="POST" onsubmit="showLoading()">
                                        <input type="hidden" name="payment_method" value="card" id="paymentMethod">
                                        
                                        <!-- Card Form -->
                                        <div class="payment-form active" id="cardForm">
                                            <div class="mb-3">
                                                <label class="form-label">Card Number</label>
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fas fa-credit-card"></i></span>
                                                    <input type="text" name="card_number" 
                                                           class="form-control" placeholder="4242 4242 4242 4242"
                                                           pattern="\d{16}" required
                                                           oninput="formatCardNumber(this)">
                                                </div>
                                            </div>
                                            <div class="row g-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Expiry Date</label>
                                                    <div class="input-group">
                                                        <span class="input-group-text"><i class="fas fa-calendar-alt"></i></span>
                                                        <input type="text" name="expiry" 
                                                               class="form-control" placeholder="MM/YY"
                                                               pattern="\d{2}/\d{2}" required
                                                               oninput="formatExpiry(this)">
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">CVC</label>
                                                    <div class="input-group">
                                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                                        <input type="text" name="cvc" 
                                                               class="form-control" placeholder="CVC"
                                                               pattern="\d{3,4}" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- UPI Form -->
                                        <div class="payment-form" id="upiForm">
                                            <div class="mb-3">
                                                <label class="form-label">UPI ID</label>
                                                <div class="input-group">
                                                    <span class="input-group-text"><i class="fas fa-mobile-alt"></i></span>
                                                    <input type="text" name="upi_id" 
                                                           class="form-control" placeholder="username@upi"
                                                           pattern="[\w.-]+@[\w.-]+" required>
                                                </div>
                                                <small class="text-muted mt-1 d-block">e.g. yourname@oksbi</small>
                                            </div>
                                        </div>

                                        <div class="mt-4">
                                            <button type="submit" class="btn btn-primary btn-lg w-100 py-3">
                                                <i class="fas fa-lock me-2"></i>
                                                Confirm Payment - ₹<?= number_format($booking['price'] * $booking['num_passengers'], 2) ?>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
        <?php endif; ?>
    </div>

    <script>
        document.querySelectorAll('.method-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        // सभी tabs से active क्लास हटाएं
        document.querySelectorAll('.method-tab').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        
        // Payment method अपडेट करें
        const method = this.dataset.method;
        document.getElementById('paymentMethod').value = method;
        
        // संबंधित फॉर्म दिखाएं
        document.querySelectorAll('.payment-form').forEach(form => {
            form.classList.remove('active');
            form.querySelectorAll('input').forEach(input => input.required = false);
        });
        
        const activeForm = document.getElementById(method + 'Form');
        activeForm.classList.add('active');
        activeForm.querySelectorAll('input').forEach(input => input.required = true);
    });
});
        // Enhanced Payment Method Toggle
        document.querySelectorAll('.method-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.method-tab').forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                
                const method = this.dataset.method;
                document.getElementById('paymentMethod').value = method;
                document.querySelectorAll('.payment-form').forEach(form => form.classList.remove('active'));
                document.getElementById(method + 'Form').classList.add('active');
            });
        });

        // Card Number Formatting
        function formatCardNumber(input) {
            let value = input.value.replace(/\D/g, '');
            value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
            input.value = value.substring(0, 19);
        }

        // Expiry Date Formatting
        function formatExpiry(input) {
            let value = input.value.replace(/\D/g, '');
            if (value.length > 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            input.value = value.substring(0, 5);
        }
        // Enhanced Ticket Toggle
        function toggleTicket() {
            const ticket = document.getElementById('ticketContainer');
            ticket.classList.toggle('visible');
        }

        // Automatically show ticket after payment
        <?php if($payment_success): ?>
            document.addEventListener('DOMContentLoaded', function() {
                const ticket = document.getElementById('ticketContainer');
                ticket.classList.add('visible');
            });
        <?php endif; ?>

        // Loading Overlay
        function showLoading() {
            document.getElementById('loadingOverlay').style.display = 'flex';
            return true;
        }
    </script>

<?php include 'footer.php'; ?>
</body>
</html>