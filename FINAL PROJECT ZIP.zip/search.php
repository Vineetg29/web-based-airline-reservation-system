<?php
include 'db.php';
include 'header.php';

if (!isset($_GET['id'])) {
    die("Invalid request.");
}

$flight_id = $_GET['id'];

// Fetch flight details
$stmt = $pdo->prepare("SELECT * FROM flights WHERE id = ?");
$stmt->execute([$flight_id]);
$flight = $stmt->fetch();

if (!$flight) {
    die("Flight not found.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_name = $_POST['user_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $passengers = $_POST['passengers'];
    $total_price = $flight['price'] * $passengers;

    $stmt = $pdo->prepare("INSERT INTO bookings (flight_id, user_name, email, phone, passengers, total_price) 
                           VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$flight_id, $user_name, $email, $phone, $passengers, $total_price]);

    echo "<script>alert('Booking successful!'); window.location='search.php';</script>";
}
?>

<link rel="stylesheet" href="css/style.css">

<div class="container booking-form">
    <h3>Book Flight - <?= htmlspecialchars($flight['flight_number']) ?></h3>
    
    <form method="POST">
        <label>Name:</label>
        <input type="text" name="user_name" required>
        
        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Phone:</label>
        <input type="text" name="phone" required>

        <label>Passengers:</label>
        <select name="passengers" required>
            <option value="1">1 Passenger</option>
            <option value="2">2 Passengers</option>
            <option value="3">3 Passengers</option>
        </select>

        <p><strong>Total Price:</strong> ₹<?= number_format($flight['price']) ?> per passenger</p>

        <button type="submit">Confirm Booking</button>
    </form>
</div>

<?php include 'footer.php'; ?>
