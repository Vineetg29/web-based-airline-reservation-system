<?php
session_start();

// Generate CSRF Token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

include 'header.php';
include 'navbar.php';
?>

<!-- Link External CSS -->
<link rel="stylesheet" href="style.css">

<!-- Display Success or Error Messages -->
<div class="container mt-3">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?= $_SESSION['success']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?= $_SESSION['error']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>
</div>

<!-- Contact Hero Section -->
<div class="hero position-relative">
    <img src="contact-hero1.jpg" class="img-fluid w-100 hero-image" alt="Airline Contact">
    <div class="hero-overlay position-absolute top-50 start-50 translate-middle text-center">
        <h1 class="text-white display-4">Contact Skyways Airlines</h1>
        <p class="text-white lead">We're here to help you 24/7</p>
    </div>
</div>

<!-- Contact Content -->
<div class="container my-5">
    <div class="row g-5">
        <!-- Contact Form -->
        <div class="col-md-7">
            <div class="contact-form shadow-lg p-4 rounded bg-white">
                <h3 class="mb-4"><i class="fas fa-paper-plane"></i> Send us a Message</h3>
                <form action="send-contact.php" method="POST">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Your Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" name="email" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Subject</label>
                            <input type="text" class="form-control" name="subject" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Message</label>
                            <textarea class="form-control" name="message" rows="5" required></textarea>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-paper-plane"></i> Send Message
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Contact Info -->
        <div class="col-md-5">
            <div class="contact-info shadow-lg p-4 rounded bg-white">
                <h3 class="mb-4"><i class="fas fa-headset"></i> Contact Information</h3>
                <div class="info-item mb-4">
                    <div class="icon-circle bg-primary">
                        <i class="fas fa-map-marker-alt text-white"></i>
                    </div>
                    <h5>Headquarters</h5>
                    <p>Skyways Plaza, 123 Airport Road<br>New York, NY 10001</p>
                </div>
                <div class="info-item mb-4">
                    <div class="icon-circle bg-success">
                        <i class="fas fa-phone-alt text-white"></i>
                    </div>
                    <h5>Phone Numbers</h5>
                    <p>Reservations: +91 9711193956 <br>Support: +91 (800) 890-1234</p>
                </div>
                <div class="info-item mb-4">
                    <div class="icon-circle bg-warning">
                        <i class="fas fa-envelope text-white"></i>
                    </div>
                    <h5>Email Addresses</h5>
                    <p>Bookings: bookings@skyways.com<br>Support: vgvineet@gmail.com</p>
                </div>
                <div class="social-links mt-4">
                    <h5>Follow Us</h5>
                    <a href="#" class="btn btn-outline-primary me-2"><i class="fab fa-facebook"></i></a>
                    <a href="#" class="btn btn-outline-info me-2"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="btn btn-outline-danger me-2"><i class="fab fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/in/vineet-gupta-a78568214" 
                       class="btn btn-outline-dark"
                       target="_blank"
                       rel="noopener noreferrer"
                       aria-label="Vineet Gupta LinkedIn Profile">
                        <i class="fab fa-linkedin"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Map Section -->
<div class="container-fluid px-0 mb-5">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387193.305935303!2d-74.25986548229184!3d40.69714941932609!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sin!4v1718871435932!5m2!1sen!2sin" 
            width="100%" 
            height="450" 
            style="border:0;" 
            allowfullscreen="" 
            loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade">
    </iframe>
</div>

<?php include 'footer.php'; ?>
