<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

// Database connection with your actual credentials
$db = new mysqli('localhost', 'root', '', 'airline_reservation');

// Check connection
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_flight'])) {
        // Add new flight
        $flight_number = $db->real_escape_string($_POST['flight_number']);
        $airline = $db->real_escape_string($_POST['airline']);
        $departure_city = $db->real_escape_string($_POST['departure_city']);
        $arrival_city = $db->real_escape_string($_POST['arrival_city']);
        $departure_date = $db->real_escape_string($_POST['departure_date']);
        $departure_time = $db->real_escape_string($_POST['departure_time']);
        $arrival_time = $db->real_escape_string($_POST['arrival_time']);
        $price = (float)$_POST['price'];
        $seats_available = (int)$_POST['seats_available'];
        $class = $db->real_escape_string($_POST['class']);
        
        $query = "INSERT INTO flights (flight_number, airline, departure_city, arrival_city, departure_date, departure_time, arrival_time, price, seats_available, class) 
                  VALUES ('$flight_number', '$airline', '$departure_city', '$arrival_city', '$departure_date', '$departure_time', '$arrival_time', $price, $seats_available, '$class')";
        
        if (!$db->query($query)) {
            die("Error adding flight: " . $db->error);
        }
        
        // Refresh to show new flight
        header("Location: manage_flights.php");
        exit();
        
    } elseif (isset($_POST['update_flight'])) {
        // Update existing flight
        $id = (int)$_POST['flight_id'];
        $flight_number = $db->real_escape_string($_POST['flight_number']);
        $airline = $db->real_escape_string($_POST['airline']);
        $departure_city = $db->real_escape_string($_POST['departure_city']);
        $arrival_city = $db->real_escape_string($_POST['arrival_city']);
        $departure_date = $db->real_escape_string($_POST['departure_date']);
        $departure_time = $db->real_escape_string($_POST['departure_time']);
        $arrival_time = $db->real_escape_string($_POST['arrival_time']);
        $price = (float)$_POST['price'];
        $seats_available = (int)$_POST['seats_available'];
        $class = $db->real_escape_string($_POST['class']);
        
        $query = "UPDATE flights SET 
                  flight_number='$flight_number', 
                  airline='$airline', 
                  departure_city='$departure_city', 
                  arrival_city='$arrival_city', 
                  departure_date='$departure_date', 
                  departure_time='$departure_time', 
                  arrival_time='$arrival_time', 
                  price=$price, 
                  seats_available=$seats_available, 
                  class='$class' 
                  WHERE id=$id";
                  
        if (!$db->query($query)) {
            die("Error updating flight: " . $db->error);
        }
        
        // Refresh to show updated flight
        header("Location: manage_flights.php");
        exit();
    }
} elseif (isset($_GET['delete'])) {
    // Delete flight
    $id = (int)$_GET['delete'];
    $query = "DELETE FROM flights WHERE id=$id";
    if (!$db->query($query)) {
        die("Error deleting flight: " . $db->error);
    }
    header("Location: manage_flights.php");
    exit();
}

// Fetch all flights
$query = "SELECT * FROM flights ORDER BY departure_date ASC, departure_time ASC";
$flights = $db->query($query);
if (!$flights) {
    die("Error fetching flights: " . $db->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Flights - Airline Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
            --light-color: #f8f9fa;
            --dark-color: #34495e;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --info-color: #1abc9c;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
        }
        
        .sidebar {
            height: 100vh;
            background: var(--secondary-color);
            padding: 20px;
            color: white;
            position: fixed;
            width: 250px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding-bottom: 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .sidebar-header h3 {
            font-weight: 600;
            margin-bottom: 0;
        }
        
        .sidebar-nav {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .sidebar-nav a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 5px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
        }
        
        .sidebar-nav a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .sidebar-nav a:hover, 
        .sidebar-nav a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 30px;
            min-height: 100vh;
        }
        
        .top-bar {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .top-bar h2 {
            margin-bottom: 0;
            color: var(--secondary-color);
            font-weight: 600;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
        }
        
        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
            object-fit: cover;
        }
        
        .table-container {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.05);
        }
        
        .table th {
            border-top: none;
            color: var(--secondary-color);
            font-weight: 600;
            padding-top: 15px;
            padding-bottom: 15px;
        }
        
        .table td {
            vertical-align: middle;
            padding: 12px 15px;
        }
        
        .badge {
            padding: 6px 10px;
            font-weight: 500;
            font-size: 0.75rem;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 0.8rem;
        }
        
        .modal-content {
            border-radius: 12px;
            border: none;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        
        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
                overflow: hidden;
            }
            
            .sidebar-header h3, 
            .sidebar-nav a span {
                display: none;
            }
            
            .sidebar-nav a {
                justify-content: center;
                padding: 12px 0;
            }
            
            .sidebar-nav a i {
                margin-right: 0;
                font-size: 1.3rem;
            }
            
            .main-content {
                margin-left: 70px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid p-0">
        <div class="row g-0">
            <!-- Sidebar -->
            <div class="sidebar">
                <div class="sidebar-header">
                    <h3><i class="fas fa-plane me-2"></i> SkyAdmin</h3>
                </div>
                <nav class="sidebar-nav">
                    <a href="admin_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="manage_bookings.php">
                        <i class="fas fa-calendar-check"></i>
                        <span>Bookings</span>
                    </a>
                    <a href="manage_flights.php" class="active">
                        <i class="fas fa-plane-departure"></i>
                        <span>Flights</span>
                    </a>
                    <a href="manage_users.php">
                        <i class="fas fa-users"></i>
                        <span>Users</span>
                    </a>
                    <a href="reviews.php">
                        <i class="fas fa-chart-bar"></i>
                        <span>Reviews</span>
                    </a>
                    
                </nav>
            </div>

            <!-- Main Content -->
            <div class="main-content">
                <!-- Header -->
                <div class="top-bar">
                    <h2>Manage Flights</h2>
                    <div class="user-profile">
                        <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($_SESSION['user_name']); ?>&background=3498db&color=fff" alt="User">
                        <span class="me-3"><?php echo $_SESSION['user_name']; ?></span>
                        <a href="logout.php" class="btn btn-danger btn-sm">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>

                <!-- Add Flight Button -->
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4>Flight Management</h4>
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addFlightModal">
                        <i class="fas fa-plus me-2"></i>Add New Flight
                    </button>
                </div>

                <!-- Flights Table -->
                <div class="table-container">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Flight Number</th>
                                    <th>Airline</th>
                                    <th>Route</th>
                                    <th>Departure</th>
                                    <th>Arrival</th>
                                    <th>Price</th>
                                    <th>Seats</th>
                                    <th>Class</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($flight = $flights->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $flight['id']; ?></td>
                                    <td><?php echo htmlspecialchars($flight['flight_number']); ?></td>
                                    <td><?php echo htmlspecialchars($flight['airline']); ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($flight['departure_city']); ?></strong>
                                        <i class="fas fa-arrow-right mx-2 text-muted"></i>
                                        <strong><?php echo htmlspecialchars($flight['arrival_city']); ?></strong>
                                    </td>
                                    <td>
                                        <div><?php echo date('M d, Y', strtotime($flight['departure_date'])); ?></div>
                                        <div class="text-muted small"><?php echo date('H:i', strtotime($flight['departure_time'])); ?></div>
                                    </td>
                                    <td>
                                        <div class="text-muted small"><?php echo date('H:i', strtotime($flight['arrival_time'])); ?></div>
                                    </td>
                                    <td>₹<?php echo number_format($flight['price'], 2); ?></td>
                                    <td>
                                        <span class="badge <?php echo $flight['seats_available'] > 20 ? 'bg-success' : ($flight['seats_available'] > 0 ? 'bg-warning text-dark' : 'bg-danger'); ?>">
                                            <?php echo $flight['seats_available']; ?> available
                                        </span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo $flight['class'] == 'Business' ? 'bg-primary' : 'bg-info'; ?>">
                                            <?php echo htmlspecialchars($flight['class']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-primary edit-flight" 
                                                data-id="<?php echo $flight['id']; ?>"
                                                data-flight_number="<?php echo htmlspecialchars($flight['flight_number']); ?>"
                                                data-airline="<?php echo htmlspecialchars($flight['airline']); ?>"
                                                data-departure_city="<?php echo htmlspecialchars($flight['departure_city']); ?>"
                                                data-arrival_city="<?php echo htmlspecialchars($flight['arrival_city']); ?>"
                                                data-departure_date="<?php echo htmlspecialchars($flight['departure_date']); ?>"
                                                data-departure_time="<?php echo htmlspecialchars($flight['departure_time']); ?>"
                                                data-arrival_time="<?php echo htmlspecialchars($flight['arrival_time']); ?>"
                                                data-price="<?php echo htmlspecialchars($flight['price']); ?>"
                                                data-seats_available="<?php echo htmlspecialchars($flight['seats_available']); ?>"
                                                data-class="<?php echo htmlspecialchars($flight['class']); ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <a href="manage_flights.php?delete=<?php echo $flight['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this flight?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Flight Modal -->
    <div class="modal fade" id="addFlightModal" tabindex="-1" aria-labelledby="addFlightModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addFlightModalLabel">Add New Flight</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="flight_number" class="form-label">Flight Number</label>
                                <input type="text" class="form-control" id="flight_number" name="flight_number" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="airline" class="form-label">Airline</label>
                                <input type="text" class="form-control" id="airline" name="airline" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="departure_city" class="form-label">Departure City</label>
                                <input type="text" class="form-control" id="departure_city" name="departure_city" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="arrival_city" class="form-label">Arrival City</label>
                                <input type="text" class="form-control" id="arrival_city" name="arrival_city" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="departure_date" class="form-label">Departure Date</label>
                                <input type="date" class="form-control" id="departure_date" name="departure_date" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="class" class="form-label">Class</label>
                                <select class="form-select" id="class" name="class" required>
                                    <option value="Economy">Economy</option>
                                    <option value="Business">Business</option>
                                    <option value="First">First Class</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="departure_time" class="form-label">Departure Time</label>
                                <input type="time" class="form-control" id="departure_time" name="departure_time" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="arrival_time" class="form-label">Arrival Time</label>
                                <input type="time" class="form-control" id="arrival_time" name="arrival_time" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="price" class="form-label">Price (₹)</label>
                                <input type="number" step="0.01" class="form-control" id="price" name="price" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="seats_available" class="form-label">Seats Available</label>
                                <input type="number" class="form-control" id="seats_available" name="seats_available" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="add_flight" class="btn btn-primary">Add Flight</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Flight Modal -->
    <div class="modal fade" id="editFlightModal" tabindex="-1" aria-labelledby="editFlightModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST">
                    <input type="hidden" name="flight_id" id="edit_flight_id">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editFlightModalLabel">Edit Flight</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_flight_number" class="form-label">Flight Number</label>
                                <input type="text" class="form-control" id="edit_flight_number" name="flight_number" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_airline" class="form-label">Airline</label>
                                <input type="text" class="form-control" id="edit_airline" name="airline" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_departure_city" class="form-label">Departure City</label>
                                <input type="text" class="form-control" id="edit_departure_city" name="departure_city" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_arrival_city" class="form-label">Arrival City</label>
                                <input type="text" class="form-control" id="edit_arrival_city" name="arrival_city" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_departure_date" class="form-label">Departure Date</label>
                                <input type="date" class="form-control" id="edit_departure_date" name="departure_date" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_class" class="form-label">Class</label>
                                <select class="form-select" id="edit_class" name="class" required>
                                    <option value="Economy">Economy</option>
                                    <option value="Business">Business</option>
                                    <option value="First">First Class</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_departure_time" class="form-label">Departure Time</label>
                                <input type="time" class="form-control" id="edit_departure_time" name="departure_time" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_arrival_time" class="form-label">Arrival Time</label>
                                <input type="time" class="form-control" id="edit_arrival_time" name="arrival_time" required>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_price" class="form-label">Price (₹)</label>
                                <input type="number" step="0.01" class="form-control" id="edit_price" name="price" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_seats_available" class="form-label">Seats Available</label>
                                <input type="number" class="form-control" id="edit_seats_available" name="seats_available" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_flight" class="btn btn-primary">Update Flight</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Handle edit flight button clicks
        document.querySelectorAll('.edit-flight').forEach(button => {
            button.addEventListener('click', function() {
                const modal = new bootstrap.Modal(document.getElementById('editFlightModal'));
                
                // Set all the values from data attributes to the edit form
                document.getElementById('edit_flight_id').value = this.dataset.id;
                document.getElementById('edit_flight_number').value = this.dataset.flight_number;
                document.getElementById('edit_airline').value = this.dataset.airline;
                document.getElementById('edit_departure_city').value = this.dataset.departure_city;
                document.getElementById('edit_arrival_city').value = this.dataset.arrival_city;
                document.getElementById('edit_departure_date').value = this.dataset.departure_date;
                document.getElementById('edit_departure_time').value = this.dataset.departure_time;
                document.getElementById('edit_arrival_time').value = this.dataset.arrival_time;
                document.getElementById('edit_price').value = this.dataset.price;
                document.getElementById('edit_seats_available').value = this.dataset.seats_available;
                document.getElementById('edit_class').value = this.dataset.class;
                
                modal.show();
            });
        });
    </script>
</body>
</html>
<?php
// Close database connection
$db->close();
?>