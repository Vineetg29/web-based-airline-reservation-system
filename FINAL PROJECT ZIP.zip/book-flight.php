<?php
// Database configuration
require_once 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $trip_type = htmlspecialchars($_POST['trip_type']);
    $from_city = htmlspecialchars($_POST['from_city']);
    $to_city = htmlspecialchars($_POST['to_city']);
    $departure = htmlspecialchars($_POST['departure']);
    $return_date = htmlspecialchars($_POST['return_date']);
    $passengers = intval($_POST['passengers']);
    $class = htmlspecialchars($_POST['class']);
    $promo_code = htmlspecialchars($_POST['promo_code']);

    try {
        // Create bookings table if not exists
        $sql = "CREATE TABLE IF NOT EXISTS bookings (
            id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            trip_type VARCHAR(20) NOT NULL,
            from_city VARCHAR(50) NOT NULL,
            to_city VARCHAR(50) NOT NULL,
            departure DATE NOT NULL,
            return_date DATE,
            passengers INT(2) NOT NULL,
            class VARCHAR(20) NOT NULL,
            promo_code VARCHAR(20),
            booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";

        $pdo->exec($sql);

        // Insert booking
        $stmt = $pdo->prepare("INSERT INTO bookings 
            (trip_type, from_city, to_city, departure, return_date, passengers, class, promo_code)
            VALUES (:trip_type, :from_city, :to_city, :departure, :return_date, :passengers, :class, :promo_code)");

        $stmt->execute([
            ':trip_type' => $trip_type,
            ':from_city' => $from_city,
            ':to_city' => $to_city,
            ':departure' => $departure,
            ':return_date' => $return_date,
            ':passengers' => $passengers,
            ':class' => $class,
            ':promo_code' => $promo_code
        ]);

        header("Location: index.php?booking=success");
        exit();

    } catch(PDOException $e) {
        error_log($e->getMessage());
        header("Location: index.php?booking=error");
        exit();
    }
} else {
    header("Location: booking-form.php");
    exit();
}