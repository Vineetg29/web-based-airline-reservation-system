<?php
session_start();
session_destroy(); // Destroy all session data

// Redirect to login or home page
header("Location: login.php"); 
exit();
?>
