<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Airline Reservation</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3498db;
            --secondary-color: #2c3e50;
            --accent-color: #e74c3c;
            --light-color: #f8f9fa;
            --dark-color: #34495e;
            --success-color: #2ecc71;
            --warning-color: #f39c12;
            --info-color: #1abc9c;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-color);
        }

        .sidebar {
            height: 100vh;
            background: var(--secondary-color);
            padding: 20px;
            color: white;
            position: fixed;
            width: 250px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .sidebar.collapsed {
            width: 70px;
        }

        .sidebar-header {
            padding-bottom: 20px;
            margin-bottom: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h3 {
            font-weight: 600;
            margin-bottom: 0;
            transition: opacity 0.3s;
        }

        .sidebar.collapsed .sidebar-header h3 {
            opacity: 0;
        }

        .sidebar-nav {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .sidebar-nav a {
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 5px;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            white-space: nowrap;
        }

        .sidebar-nav a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
            transition: margin 0.3s;
        }

        .sidebar.collapsed .sidebar-nav a span {
            display: none;
        }

        .sidebar-nav a:hover, 
        .sidebar-nav a.active {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .main-content {
            margin-left: 250px;
            padding: 30px;
            min-height: 100vh;
            transition: margin 0.3s ease;
        }

        .sidebar.collapsed + .main-content {
            margin-left: 70px;
        }

        .top-bar {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .top-bar h2 {
            margin-bottom: 0;
            color: var(--secondary-color);
            font-weight: 600;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
        }

        /* Rest of your existing styles remain the same */
        /* ... (Include all previous CSS styles here) ... */

        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
            }
            
            .sidebar:not(.collapsed) {
                width: 250px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .sidebar-header h3, 
            .sidebar-nav a span {
                display: none;
            }
            
            .sidebar:not(.collapsed) .sidebar-header h3,
            .sidebar:not(.collapsed) .sidebar-nav a span {
                display: inline-block;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid p-0">
        <div class="row g-0">
            <!-- Sidebar -->
            <div class="sidebar">
                <div class="sidebar-header">
                    <h3><i class="fas fa-plane me-2"></i> SkyAdmin</h3>
                </div>
                <nav class="sidebar-nav">
                    <a href="admin_dashboard.php" class="<?= basename($_SERVER['PHP_SELF']) == 'admin_dashboard.php' ? 'active' : '' ?>">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="manage_bookings.php" class="<?= basename($_SERVER['PHP_SELF']) == 'manage_bookings.php' ? 'active' : '' ?>">
                        <i class="fas fa-calendar-check"></i>
                        <span>Bookings</span>
                    </a>
                    <a href="manage_flights.php" class="<?= basename($_SERVER['PHP_SELF']) == 'manage_flights.php' ? 'active' : '' ?>">
                        <i class="fas fa-plane-departure"></i>
                        <span>Flights</span>
                    </a>
                    <a href="manage_users.php" class="<?= basename($_SERVER['PHP_SELF']) == 'manage_users.php' ? 'active' : '' ?>">
                        <i class="fas fa-users"></i>
                        <span>Users</span>
                    </a>
                    <a href="reviews.php" class="<?= basename($_SERVER['PHP_SELF']) == 'reviews.php' ? 'active' : '' ?>">
                        <i class="fas fa-chart-bar"></i>
                        <span>Reviews</span>
                    </a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="main-content">
                <!-- Top Bar -->
                <div class="top-bar">
                    <button class="btn btn-secondary d-lg-none" id="sidebarToggle">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h2>Dashboard Overview</h2>
                    <div class="user-profile">
                        <img src="https://ui-avatars.com/api/?name=<?= urlencode(htmlspecialchars($_SESSION['user_name'])) ?>&background=3498db&color=fff" 
                             alt="<?= htmlspecialchars($_SESSION['user_name']) ?>">
                        <span class="me-3"><?= htmlspecialchars($_SESSION['user_name']) ?></span>
                        <a href="logout.php" class="btn btn-danger btn-sm">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                    </div>
                </div>

                <!-- Summary Cards -->
                <div class="row g-4 mb-4">
                    <!-- Cards content same as before -->
                    <div class="row g-4 mb-4">
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="card summary-card" style="background-color: var(--primary-color); color: white;">
                            <i class="fas fa-calendar card-icon"></i>
                            <div class="card-body">
                                <h5>Total Bookings</h5>
                                <h2>1,234</h2>
                                <small>+12% from last month</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="card summary-card" style="background-color: var(--success-color); color: white;">
                            <i class="fas fa-plane card-icon"></i>
                            <div class="card-body">
                                <h5>Active Flights</h5>
                                <h2>56</h2>
                                <small>5 flights today</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="card summary-card" style="background-color: var(--warning-color); color: white;">
                            <i class="fas fa-users card-icon"></i>
                            <div class="card-body">
                                <h5>Registered Users</h5>
                                <h2>4,567</h2>
                                <small>123 new this week</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="card summary-card" style="background-color: var(--info-color); color: white;">
                            <i class="fas fa-dollar-sign card-icon"></i>
                            <div class="card-body">
                                <h5>Revenue</h5>
                                <h2>$12,345</h2>
                                <small>Current month</small>
                            </div>
                        </div>
                    </div>
                </div>
                </div>

                <!-- Chart Section -->
                <div class="chart-container mb-4">
                    <h5>Booking Trends</h5>
                    <div style="height: 300px;">
                        <canvas id="bookingChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Sidebar Toggle
        document.getElementById('sidebarToggle').addEventListener('click', () => {
            document.querySelector('.sidebar').classList.toggle('collapsed');
        });

        // Chart Initialization
        const ctx = document.getElementById('bookingChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Monthly Bookings',
                    data: [65, 59, 80, 81, 56, 55],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.1)',
                    borderWidth: 2,
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: { beginAtZero: true },
                    x: { grid: { display: false } }
                }
            }
        });
    </script>
</body>
</html>